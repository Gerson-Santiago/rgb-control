# rgb_control module
